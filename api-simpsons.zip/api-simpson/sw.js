const cacheName = 'pwa-simpson-archivos';
const assets = [
    'index.html', 
    'html/frases.html', 
    'js/instalacion.js', 
    'bootstrap-5.3.0-alpha3-dist/css/bootstrap.min.css',
    'bootstrap-5.3.0-alpha3-dist/js/bootstrap.min.js',
    'css/estilo.css',
    'sw.js'
];

self.addEventListener('install', event => {
    console.log('El SW se instaló');

    self.skipWaiting();

    event.waitUntil(
        caches.open(cacheName)
            .then(cache => {
                console.log('Agregando recursos al caché');
                return cache.addAll(assets);
            })
            .catch(error => {
                console.log('Error al agregar recursos al caché:', error);
            })
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {

                if (response) {
                    return response;
                }


                return fetch(event.request)
                    .then(networkResponse => {

                        const responseClone = networkResponse.clone();
                        caches.open(cacheName)
                            .then(cache => {
                                cache.put(event.request, responseClone);
                            });
                        return networkResponse;
                    })
                    .catch(error => {
                        console.log('Error al recuperar el recurso de la red:', error);
                    });
            })
    );
});

self.addEventListener('activate', event => {
    console.log('El SW se activó');
});
