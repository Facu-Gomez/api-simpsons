let deferredInstallPrompt = null;
const installBtn = document.getElementById('buttonInstall')

installBtn.addEventListener('click', instalarPWA);

window.addEventListener('beforeinstallprompt', saveBeforeInstallPromptEvent);

function saveBeforeInstallPromptEvent(evt){
    deferredInstallPrompt = evt;

    installBtn.removeAttribute('hidden')
}

function instalarPWA(evt){
    deferredInstallPrompt.prompt();
    
    deferredInstallPrompt.userChoice.then((choice)=>{
        if(choice.outcome === "accepted"){
            console.log("aceptado")
        }else {
            console.log("no aceptado")
        }
        deferredInstallPrompt = null;
    })
}

window.addEventListener("appInstalled", logAppInstalled);

function logAppInstalled(evt){
    console.log('aplicacion instalada')
}