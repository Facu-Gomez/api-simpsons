window.addEventListener('DOMContentLoaded', function(){

  if('serviceWorker' in this.navigator) {
      this.navigator.serviceWorker
                  .register('../sw.js')
                  .then (res=> console.log('El SW se registro correctamente'))
                  .catch (err => console.log('El SW no se pudo registrar'))
  }

    fetch('https://thesimpsonsquoteapi.glitch.me/quotes?count=10')
      .then(response => response.json())
      .then(data => {
        let html = "";
        data.forEach(quote => {
          html += `
            <div class="col-md-6 my-3">
              <div class="card" >
                <div class="row no-gutters">
                  <div style="max-width: 200px;">
                    <img src="${quote.image}" class="card-img img-fluid">
                  </div>
                  <div class="col-md-6">
                    <div class="card-body">
                      <h5 class="card-title">${quote.character}</h5>
                      <p class="card-text">${quote.quote}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          `;
        });
        const container = document.getElementById('container');
        container.innerHTML = `<div class="row">${html}</div>`;
      })
      .catch(error => console.error(error));

      function notificacion(){


        Notification.requestPermission()
      .then(function(result){
        console.log(result)
      })
      
      if ('Notification' in window) {

        Notification.requestPermission()
          .then(permission => {
            if (permission === 'granted') {
              const notification = new Notification('Homero Simpson', {
                body: "'D'oh'",
                icon: '../img/iconos/noti.jpg' 
              });
            }
          })
          .catch(error => {
            console.error('Error al solicitar permiso de notificación:', error);
          });
      }
      };

      notificacion();
      offline();
  }
  
);
let conexion = document.getElementById("conexion")
let div = document.getElementById("divconexion")
let compartir = document.getElementById("compartir")
compartir.addEventListener('click', compalta)

window.addEventListener("online", (event) => {
  if(navigator.onLine == true){
    conexion.innerText = "Conexion: 📡";

    div.appendChild(conexion)
  }
});
window.addEventListener("offline", (event) => {
  if(navigator.onLine == false){
    conexion.innerText = "Conexion: 🔌";

    div.appendChild(conexion)
  }
});

function offline() {
  
  console.log(conexion)
  if(navigator.onLine == true){
    conexion.innerText = "Conexion: 📡";

    div.appendChild(conexion)
  }else{
    conexion.innerText = "Conexion: 🔌";

    div.appendChild(conexion)
  }

}


function compalta() {
  navigator.share({
    title: 'PWA SIMPSON',
    text: 'MIRA ESTAS FRASES DE LOS SIMPSONS',
    url: 'https://api-simpson.netlify.app'
  })
    .then(() => console.log('Contenido compartido exitosamente'))
    .catch(error => console.log('Error al compartir contenido:', error));
};

